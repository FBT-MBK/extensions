import { S as Sa, D as Aa, F as Fy, G as Go, H as di, P as Pa, O as Oa, N as Mo, Q as va, U as _a, V as Fa } from '../base64-4a43c5c0.js';
import { s as sN, E as En } from '../App-93c1f4fc.js';

function h(t){di(t,"svelte-1onuouz","html,body{height:100%;width:100%}:root{--drawer-width:256px;--app-content-width:calc(100% - 260px);--top-bar-height:48px;--top-bar-width:calc(100% - 255px)}");}function m(t){let s,a;return s=new sN({props:{isFullscreen:!0}}),{c(){Pa(s.$$.fragment);},m(t,e){Oa(s,t,e),a=!0;},p:Mo,i(t){a||(va(s.$$.fragment,t),a=!0);},o(t){_a(s.$$.fragment,t),a=!1;},d(t){Fa(s,t);}}}function l(t){return En.set(!0),[]}Fy();const w=new class extends Sa{constructor(t){super(),Aa(this,t,l,m,Go,{},h);}}({target:document.body});

export { w as default };
