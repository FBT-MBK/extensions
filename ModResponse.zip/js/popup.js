import { S as Sa, D as Aa, F as Fy, G as Go, H as di, P as Pa, O as Oa, N as Mo, Q as va, U as _a, V as Fa } from '../base64-4a43c5c0.js';
import { s as sN } from '../App-93c1f4fc.js';

function h(t){di(t,"svelte-c57hl2","body{height:500px;width:620px !important}:root{--drawer-width:36px;--app-content-width:calc(100% - 36px);--top-bar-height:48px;--top-bar-width:585px}");}function m(t){let a,s;return a=new sN({}),{c(){Pa(a.$$.fragment);},m(t,e){Oa(a,t,e),s=!0;},p:Mo,i(t){s||(va(a.$$.fragment,t),s=!0);},o(t){_a(a.$$.fragment,t),s=!1;},d(t){Fa(a,t);}}}Fy();const l=new class extends Sa{constructor(t){super(),Aa(this,t,null,m,Go,{},h);}}({target:document.body});

export { l as default };
